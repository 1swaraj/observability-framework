import json
import requests

def lambda_handler(event, context):
    body = json.loads(event["body"])
    digital_ocean_key = body["api"]
    total_cost = 0
    headers = {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer '+digital_ocean_key,
    }
    print(droplets)
    response = requests.get('https://api.digitalocean.com/v2/customers/my/balance', headers=headers)
    print(response.json())
