import json
from dopy.manager import DoManager
import requests

def lambda_handler(event, context):
    body = json.loads(event["body"])
    digital_ocean_key = body["api"]
    do = DoManager(None, digital_ocean_key, api_version=2)
    dropletsinfo = []
    droplets = do.all_active_droplets()
    return {
        'statusCode': 401,
        'body': json.dumps(droplets)
    }
